/*
Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/

/*Include Libraries*/
#include "common.h"

/*Get column function*/
void get_column(char *line, char *column, int col) {

    /*Declare and initialize values*/
    int tab = 0;
    int tabEnd = 0;
    int tabFront = 0;
    int i;

    /*Find first tabs between column*/
    for(i = 0; i < strlen(line) + 1; i++) {

        if(line[i] == '\t' || line[i] == '\n') {

            tab++;

            if(tab == col) {

                tabFront = i;

            } else if (tab == col + 1) {

                tabEnd = i;
                break;

            }

        }

    }

    /*Set string accordingly*/
    if(col == 0) {

        strncpy(column, line + tabFront, tabEnd - tabFront);
        column[tabEnd - tabFront] = '\0';

    } else {

        strncpy(column, line + tabFront + 1, tabEnd - tabFront);
        column[tabEnd - tabFront - 1] = '\0';

    }

}

/*Reverse string function*/
void reverse(char *original) {

    /*Initialize Values*/
    int i = 0;
    int j = strlen(original) - 1;
    char temp;

    /*Swap first and last and increment till you meet in the middle*/
    while(i < j) {

        /*printf("%d : %c\t%d: %c\n", i, original[i], j, original[j]);*/

        temp = original[i];
        original[i] = original[j];
        original[j] = temp;

        /*printf("%d : %c\t%d: %c\n", i, original[i], j, original[j]);*/

        i++;
        j--;

    }

}
