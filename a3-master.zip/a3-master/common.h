/*
Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/

/*Include Libraries*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*Function Prototypes*/
void get_column(char *line, char *column, int col);
void reverse(char *);
