/*
Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/

/*Include Libraries*/
#include "binary.h"

/*Define Max Buffer*/
#define MAX_BUFFER 1000

/*Main Function*/
int main(int argc, char *argv[]) {

    /*Check Argument Count*/
    if(argc < 2) {

        return -1;

    }

    /*Define variables*/
    char line[MAX_BUFFER], command[MAX_BUFFER], subject[MAX_BUFFER];
    int i, j;
    int start = 0;
    int end = 0;

    /*Print first character*/
    printf(">");

    /*Get input from user*/
    fgets(line, MAX_BUFFER, stdin);

    /*Find where command first character is*/
    for(i = 0; line[i] == ' '; i++) {

        if(i == 0) {

            start = i;

        } else {

            start = i + 1;

        }

    }

    /*Find end of command*/
    for(j = start; line[j] != ' '; j++) {

        command[j - start] = line[j];

    }

    /*Set null terminator and set start for subject*/
    command[j - start] = '\0';
    start = j + 1;

    /*Find end of subject*/
    for(i = strlen(line) - 1; line[i] == ' ' | line[i] == '\n'; i--) {

       end = i;

    }

    /*Set subject*/
    for(i = start; i <= end; i++) {

        subject[i - start] = line[i];

    }
    subject[i - start - 1] = '\0';

    /*Create pointer with subject*/
    char *test = strdup(subject);

    /*Create array and binary trees*/
    struct name_array *arrptr;
    arrptr = get_name(argv[1]);
    build_pNindex(arrptr);
    build_nindex(arrptr);

    struct title_array *arrptr2;
    arrptr2 = get_title(argv[1]);
    build_ptindex(arrptr2);
    build_tindex(arrptr2);

    struct principals_array *arrptr3;
    arrptr3 = get_principals(argv[1]);
    build_nindexP(arrptr3);
    build_tindexP(arrptr3);

    struct title_basics *node;
    struct title_principals *node2;
    struct name_basics *node3;

    struct binary_tree *tree;

    /*If command is name or title*/
    if(strcmp(command, "name") == 0) {

      /*Fine nconst for person*/
      node3 = find_primary_name(arrptr, test);

      if(NULL != node3) {

          /*Fine binary node*/
          reverse(node3->nconst);
          tree = find_nconstPT(arrptr3, node3->nconst);

          if(NULL != tree) {

            /*Print movies for person and characters*/
            printMovies(tree, node3->nconst, arrptr2);

          } else {

              printf("Search Not Found\n");

          }

      } else {

          printf("Search Not Found\n");

      }

    } else if(strcmp(command, "title") == 0) {

      /*Find tconst for movie*/
      node = find_primary_title(arrptr2, test);

      if(NULL != node) {

        /*Find binary node*/
        tree = find_tconstPT(arrptr3, node->tconst);

        if(NULL != tree) {

          /*Print people and characters*/
          printNames(tree, node->tconst, arrptr);

        } else {

            printf("Search Not Found\n");

        }

      } else {

            printf("Search Not Found\n");

        }

    }

    /*Free all pointers, arrays and binary Trees*/
    free(test);

    free_tree(arrptr->roots[0]);
    free_tree(arrptr->roots[1]);

    free_tree(arrptr2->roots[0]);
    free_tree(arrptr2->roots[1]);

    free_tree(arrptr3->roots[0]);
    free_tree(arrptr3->roots[1]);

    for(i = 0; i < arrptr->nelements; i++) {

        free((arrptr->arr)[i].nconst);
        free((arrptr->arr)[i].primaryName);

    }

    free(arrptr->arr);
    free(arrptr);

    for(i = 0; i < arrptr2->nelements; i++) {

        free((arrptr2->arr)[i].tconst);
        free((arrptr2->arr)[i].primaryTitle);

    }

    free(arrptr2->arr);
    free(arrptr2);

    for(i = 0; i < arrptr3->nelements; i++) {

        free((arrptr3->arr)[i].tconst);
        free((arrptr3->arr)[i].nconst);
        free((arrptr3->arr)[i].characters);

    }

    free(arrptr3->arr);
    free(arrptr3);

    return 0;

}
