/*
Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/

/*Include Libraries*/
#include "binary.h"

/*Create node in binary tree for title and name basics*/
void add_node(struct binary_tree **root, char *key, void *address) {

    /*Find null node in tree*/
    if(*root) {

        if(strcmp(key, (**root).key) < 0) {

            add_node(&((*root)->children[0]), key, address);

        } else {

            add_node(&((*root)->children[1]), key, address);

        }

    } else {

        /*Add node*/
        (*root) = malloc(sizeof(struct binary_tree));
        (*root)->key = key;
        /*(*root)->data = malloc(sizeof(address));*/
        (*root)->data = address;
        /*printf("%s\n", ((struct title_principals *) (*root)->data)->nconst);*/
        (*root)->children[0] = NULL;
        (*root)->children[1] = NULL;

    }

}

/*Create tile principals node*/
void add_nodeTP(struct binary_tree **root, char *key, struct title_principals *address) {

    /*Find null node*/
    if(*root) {

        if(strcmp(key, (**root).key) < 0) {

            add_nodeTP(&((*root)->children[0]), key, address);

        } else {

            add_nodeTP(&((*root)->children[1]), key, address);

        }

    } else {

        /*Create node*/
        (*root) = malloc(sizeof(struct binary_tree));
        (*root)->key = key;
        /*(*root)->data = malloc(sizeof(struct title_principals *));*/
        (*root)->data = address;
        ((struct title_principals *) (*root)->data)->nconst = address->nconst;
        ((struct title_principals *) (*root)->data)->tconst = address->tconst;
        ((struct title_principals *) (*root)->data)->characters = address->characters;
        /*((struct title_principals *) (*root)->data)->nconst = strdup(address->nconst);
        ((struct title_principals *) (*root)->data)->tconst = strdup(address->tconst);
        ((struct title_principals *) (*root)->data)->characters = strdup(address->characters);*/
        (*root)->children[0] = NULL;
        (*root)->children[1] = NULL;

    }

}

/*Find node in title and name basics*/
void* find_node(struct binary_tree *root, char *key) {

    /*Run through tree and return structure stored in data for node with the same key*/
    if(root) {

        if(strcmp(key, (*root).key) == 0) {

            return root->data;

        } else if(strcmp(key, (*root).key) < 0) {

            return find_node(root->children[0], key);

        } else {

            return find_node(root->children[1], key);

        }

    } else {

        return NULL;

    }

}

/*Find node in title principals*/
struct binary_tree* find_nodeRoot(struct binary_tree *root, char *key) {

    /*Find node with same key and return it*/
    if(root) {

        if(strcmp(key, (*root).key) == 0) {

            return root;

        } else if(strcmp(key, (*root).key) < 0) {

            return find_nodeRoot(root->children[0], key);

        } else {

            return find_nodeRoot(root->children[1], key);

        }

    } else {

        return NULL;

    }

}

/*Print movies for certain person*/
void printMovies(struct binary_tree *root, char *key, struct title_array *ptr) {

    /*Move through tree*/
    if(root) {

        struct title_basics *movies;

        /*If key matches*/
        if(strcmp(root->key, key) == 0) {

            /*Check if this movie is in title array*/
            movies = find_tconst(ptr, (char *) ((struct title_principals *) (*root).data)->tconst);

            /*Print if this is a movie*/
            if(movies != NULL) {

                printf("%s : %s\n", movies->primaryTitle, (char *) ((struct title_principals *) ((*root).data))->characters);

            }

            /*Move through tree*/
            printMovies(root->children[0], key, ptr);
            printMovies(root->children[1], key, ptr);

        } else if(strcmp(root->key, key) < 0){

            printMovies(root->children[0], key, ptr);

        } else {

            printMovies(root->children[1], key, ptr);

        }

    }

}

/*Print people for certain movie*/
void printNames(struct binary_tree *root, char *key, struct name_array *ptr) {

    /*Run through binary tree*/
    if(root) {

        struct name_basics *person;

        /*Check if key matches*/
        if(strcmp(root->key, key) == 0) {

            /*Reverse nconst and check if this person is in name basics*/
            reverse((char *) ((struct title_principals *) (*root).data)->nconst);
            person = find_nconst(ptr, (char *) ((struct title_principals *) (*root).data)->nconst);

            /*Print info out if person is in name basics*/
            if(person != NULL) {

                printf("%s : %s\n", person->primaryName, (char *) ((struct title_principals *) ((*root).data))->characters);

            }

            /*Move through tree*/
            printNames(root->children[0], key, ptr);
            printNames(root->children[1], key, ptr);

        } else if(strcmp(root->key, key) < 0){

            printNames(root->children[0], key, ptr);

        } else {

            printNames(root->children[1], key, ptr);

        }

    }

}

/*Free binary tree*/
void free_tree(struct binary_tree *root) {

    if (root){

        free_tree(root->children[0]);
        free_tree(root->children[1]);

        free(root);

    }

}
