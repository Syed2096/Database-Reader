/*
Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/

/*Include Libraries*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*Name basics struct*/
struct name_basics {

    char *nconst;
    char *primaryName;

};

/*Array struct*/
struct name_array {

    struct name_basics *arr;
    long nelements;
    struct binary_tree *roots[2];

};

/*Function Prototypes*/
struct name_array* get_name(char *directory);
struct name_basics* find_primary_name(struct name_array *, char *);
struct name_basics* find_nconst(struct name_array *, char *);
void build_pNindex(struct name_array *);
void build_nindex(struct name_array *);
