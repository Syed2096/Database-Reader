/*
Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/

/*Include Libraries*/
#include "binary.h"

/*Create buffer size*/
#define BUFFER_SIZE 1000

/*Get Title function*/
struct title_array* get_title(char *directory) {

    /*Array function*/
    struct title_array *arrptr;
    char buffer[BUFFER_SIZE];
    char column[BUFFER_SIZE];

    /*Create directory*/
    char *fileLoc = malloc(strlen(directory) + 18);
    strcpy(fileLoc, directory);
    strcat(fileLoc, "/title.basics.tsv");
    fileLoc[strlen(fileLoc)] = '\0';

    /*Open file*/
    FILE *fp = fopen(fileLoc, "r");
    if(fp == NULL) {

        fprintf(stderr, "Error: File\n");
        exit(-1);

    }

    /*Free directory*/
    free(fileLoc);

    /*Malloc array*/
    arrptr = malloc(sizeof(struct title_array));
    arrptr->nelements = 0;

    /*Set roots*/
    arrptr->roots[0] = 0;
    arrptr->roots[1] = 0;

    /*Read file*/
    while(!feof(fp)) {

        if(fgets(buffer, BUFFER_SIZE, fp) == NULL) {

            break;

        }

        if(strlen(buffer) == BUFFER_SIZE - 1) {

            fprintf(stderr, "Error: BUFFER TO SMALL\n");
            exit(-1);

        }

        /*Get column and increment based on what it says*/
        get_column(buffer, column, 1);

        if(NULL != strstr(column, "movie")) {

            get_column(buffer, column, 4);

            if(NULL != strstr(column, "0")) {

                (arrptr->nelements)++;

            }

        }

    }

    /*Malloc size for all elements*/
    arrptr->arr = malloc(sizeof(struct title_basics) * (arrptr->nelements));

    /*printf("%d\n", arrptr->nelements);*/

    /*Set elements to 0*/
    (arrptr->nelements) = 0;

    /*Go to begining of file*/
    fseek(fp, 0, SEEK_SET);

    /*Read through file again*/
    while(!feof(fp)) {

        if(fgets(buffer, BUFFER_SIZE, fp) == NULL) {

            break;

        }

        if(strlen(buffer) == BUFFER_SIZE - 1) {

            fprintf(stderr, "Error: BUFFER TO SMALL\n");
            exit(-1);

        }

        get_column(buffer, column, 1);

        if(NULL != strstr(column, "movie")) {

            get_column(buffer, column, 4);

            if(NULL != strstr(column, "0")) {

                /*Set values*/
                get_column(buffer, column, 0);
                reverse(column);
                (arrptr->arr)[arrptr->nelements].tconst = strdup(column);

                get_column(buffer, column, 2);
                (arrptr->arr)[arrptr->nelements].primaryTitle = strdup(column);

                (arrptr->nelements)++;

            }

        }

    }

    /*Free pointer and return arrptr*/
    fclose(fp);
    return arrptr;

}

/*Find primary title function*/
struct title_basics* find_primary_title(struct title_array *ptr, char *title) {

    struct title_basics *node;
    node = find_node(ptr->roots[0], title);

    return node;

}

/*Find tconst function*/
struct title_basics* find_tconst(struct title_array *ptr, char *tconst) {

    struct title_basics *node;
    node = find_node(ptr->roots[1], tconst);

    return node;

}

/*Build primaryTitle tree*/
void build_ptindex(struct title_array *ptr) {

    int i;

    for(i = 0; i < (ptr->nelements); i++) {

        add_node(&ptr->roots[0], (ptr->arr)[i].primaryTitle, &((*ptr).arr)[i]);

    }

}

/*Build tconst tree*/
void build_tindex(struct title_array *ptr) {

    int i;

    for(i = 0; i < (ptr->nelements); i++) {

        add_node(&ptr->roots[1], (ptr->arr)[i].tconst, &((*ptr).arr)[i]);

    }

}
