/*
Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/

/*Include Libraries*/
#include "name.h"
#include "title.h"
#include "principals.h"
#include "common.h"

/*Binary tree node*/
struct binary_tree {

    char *key;
    void *data;
    struct binary_tree *children[2];

};

/*Function Prototypes*/
void add_node(struct binary_tree **, char *, void *);
void add_nodeTP(struct binary_tree **root, char *key, struct title_principals *address);
void printMovies(struct binary_tree *, char *, struct title_array *);
void printNames(struct binary_tree *, char *, struct name_array *);
void* find_node(struct binary_tree *, char *);
struct binary_tree* find_nodeRoot(struct binary_tree *, char *);
void free_tree(struct binary_tree*);
void free_treeTP(struct binary_tree*);
