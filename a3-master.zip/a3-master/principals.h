/*
Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/

/*Include Libraries*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*Create title_principals struct*/
struct title_principals {

    char *characters;
    char *tconst;
    char *nconst;

};

/*Create principals_array struct*/
struct principals_array {

    struct title_principals *arr;
    long nelements;
    struct binary_tree *roots[2];

};

/*Function Prototypes*/
struct principals_array* get_principals(char *);
struct title_principals* find_nconstP(struct principals_array *, char*);
struct binary_tree* find_nconstPT(struct principals_array *, char *);
struct title_principals* find_tconstP(struct principals_array *, char*);
struct binary_tree* find_tconstPT(struct principals_array *, char*);
void build_nindexP(struct principals_array *);
void build_tindexP(struct principals_array *);
