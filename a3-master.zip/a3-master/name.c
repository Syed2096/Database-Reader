/*
Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/

/*Include Libraries*/
#include "binary.h"

/*Define buffer size*/
#define BUFFER_SIZE 256

/*Create function for name array*/
struct name_array* get_name(char *directory) {

    /*Set variables*/
    struct name_array *arrptr;
    char buffer[BUFFER_SIZE];
    char column[BUFFER_SIZE];

    /*Create directory*/
    char *fileLoc = malloc(strlen(directory) + 17);
    strcpy(fileLoc, directory);
    strcat(fileLoc, "/name.basics.tsv");
    fileLoc[strlen(fileLoc)] = '\0';

    /*Open file*/
    FILE *fp = fopen(fileLoc, "r");
    if(fp == NULL) {

        fprintf(stderr, "Error: File not Found\n");
        exit(-1);

    }

    /*Free directory*/
    free(fileLoc);

    /*Malloc and initialize*/
    arrptr = malloc(sizeof(struct name_array));
    arrptr->nelements = 0;

    arrptr->roots[0] = 0;
    arrptr->roots[1] = 0;

    /*Run through file and increment counter accordingly*/
    while(!feof(fp)) {

        if(fgets(buffer, BUFFER_SIZE, fp) == NULL) {

            break;

        }

        if(strlen(buffer) == BUFFER_SIZE - 1) {

            fprintf(stderr, "Error: BUFFER TO SMALL\n");
            exit(-1);

        }

        get_column(buffer, column, 4);

        if(NULL != strstr(column, "actor") || NULL != strstr(column, "actress")) {

            (arrptr->nelements)++;

        }

    }

    /*Malloc sizeof array*/
    arrptr->arr = malloc(sizeof(struct name_basics) * (arrptr->nelements));

    /*printf("%ld\n", arrptr->nelements);*/

    /*Set counter to 0*/
    (arrptr->nelements) = 0;

    /*Go to start of file*/
    fseek(fp, 0, SEEK_SET);

    /*Read through file again and set values into array*/
    while(!feof(fp)) {

        if(fgets(buffer, BUFFER_SIZE, fp) == NULL) {

            break;

        }

        if(strlen(buffer) == BUFFER_SIZE - 1) {

            fprintf(stderr, "Error: BUFFER TO SMALL\n");
            exit(-1);

        }

        get_column(buffer, column, 4);

        if(NULL != strstr(column, "actor") || NULL != strstr(column, "actress")) {

            get_column(buffer, column, 0);
            reverse(column);
            (arrptr->arr)[arrptr->nelements].nconst = strdup(column);

            get_column(buffer, column, 1);
            (arrptr->arr)[arrptr->nelements].primaryName = strdup(column);

            (arrptr->nelements)++;

        }

    }

    /*Free pointer and return array*/
    fclose(fp);
    return arrptr;

}

/*Find node in tree*/
struct name_basics* find_primary_name(struct name_array *ptr, char *name) {

    struct name_basics *node;
    node = find_node(ptr->roots[0], name);

    return node;

}

/*Find node in tree*/
struct name_basics* find_nconst(struct name_array *ptr, char *nconst) {

    struct name_basics *node;
    node = find_node(ptr->roots[1], nconst);

    return node;

}

/*Build binary tree*/
void build_pNindex(struct name_array *ptr) {

    int i;

    for(i = 0; i < (ptr->nelements); i++) {

        add_node(&ptr->roots[0], (ptr->arr)[i].primaryName, &((*ptr).arr)[i]);

    }

}

/*Build binary tree*/
void build_nindex(struct name_array *ptr) {

    int i;

    for(i = 0; i < (ptr->nelements); i++) {

        add_node(&ptr->roots[1], (ptr->arr)[i].nconst, &((*ptr).arr)[i]);

    }

}
