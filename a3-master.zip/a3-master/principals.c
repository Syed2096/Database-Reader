/*
Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/

/*Include Libraries*/
#include "binary.h"

/*Create buffer size*/
#define BUFFER_SIZE 1000

/*Create get principals function*/
struct principals_array* get_principals(char *directory) {

    /*Set variables*/
    struct principals_array *arrptr;
    char buffer[BUFFER_SIZE];
    char column[BUFFER_SIZE];

    /*Create directory*/
    char *fileLoc = malloc(strlen(directory) + 22);
    strcpy(fileLoc, directory);
    strcat(fileLoc, "/title.principals.tsv");
    fileLoc[strlen(fileLoc)] = '\0';

    /*Open file*/
    FILE *fp = fopen(fileLoc, "r");
    if(fp == NULL) {

        fprintf(stderr, "Error: File\n");
        exit(-1);

    }
    /*Free pointer*/
    free(fileLoc);

    /*Malloc and initialize*/
    arrptr = malloc(sizeof(struct principals_array));
    arrptr->nelements = 0;

    arrptr->roots[0] = 0;
    arrptr->roots[1] = 0;

    /*Run through file*/
    while(!feof(fp)) {

        if(fgets(buffer, BUFFER_SIZE, fp) == NULL) {

            break;

        }

        if(strlen(buffer) == BUFFER_SIZE - 1) {

            fprintf(stderr, "Error: BUFFER TO SMALL\n");
            exit(-1);

        }

        /*Read column*/
        get_column(buffer, column, 3);

        /*Check and increment accordingly*/
        if(NULL != strstr(column, "actor") || NULL != strstr(column, "actress")) {

            (arrptr->nelements)++;

        }

    }

    /*Malloc size of array*/
    arrptr->arr = malloc(sizeof(struct title_principals) * (arrptr->nelements));

    /*printf("%ld\n", arrptr->nelements);*/

    /*Set counter to 0*/
    (arrptr->nelements) = 0;

    /*Go to start of file*/
    fseek(fp, 0, SEEK_SET);

    /*Run through file again*/
    while(!feof(fp)) {

        if(fgets(buffer, BUFFER_SIZE, fp) == NULL) {

            break;

        }

        if(strlen(buffer) == BUFFER_SIZE - 1) {

            fprintf(stderr, "Error: BUFFER TO SMALL\n");
            exit(-1);

        }

        get_column(buffer, column, 3);

        if(NULL != strstr(column, "actor") || NULL != strstr(column, "actress")) {

            /*Read columns and add into array, reverse constants accordingly*/
            get_column(buffer, column, 0);
            reverse(column);
            (arrptr->arr)[arrptr->nelements].tconst = strdup(column);

            get_column(buffer, column, 2);
            (arrptr->arr)[arrptr->nelements].nconst = strdup(column);

            get_column(buffer, column, 5);
            (arrptr->arr)[arrptr->nelements].characters = strdup(column);

            (arrptr->nelements)++;

        }

    }

    /*Free pointer and return array pointer*/
    fclose(fp);
    return arrptr;

}

/*Build nconst binary tree*/
void build_nindexP(struct principals_array *ptr) {

    int i;

    for(i = 0; i < (ptr->nelements); i++) {

        add_nodeTP(&ptr->roots[0], (ptr->arr)[i].nconst, &((*ptr).arr)[i]);

    }

}

/*Build tconst binary tree*/
void build_tindexP(struct principals_array *ptr) {

    int i;

    for(i = 0; i < (ptr->nelements); i++) {

        add_nodeTP(&ptr->roots[1], (ptr->arr)[i].tconst, &((*ptr).arr)[i]);

    }

}

/*Find node in tree*/
struct title_principals* find_nconstP(struct principals_array *ptr, char *nconst) {

    struct title_principals *node;
    node = find_node(ptr->roots[0], nconst);

    return node;

}

/*Find binary tree node in tree*/
struct binary_tree* find_nconstPT(struct principals_array *ptr, char *nconst) {

    struct binary_tree *node;
    node = find_nodeRoot(ptr->roots[0], nconst);

    return node;

}

/*Find binary tree node in tree*/
struct binary_tree* find_tconstPT(struct principals_array *ptr, char *tconst) {

    struct binary_tree *node;
    node = find_nodeRoot(ptr->roots[1], tconst);

    return node;

}

/*Find node in tree*/
struct title_principals* find_tconstP(struct principals_array *ptr, char *tconst) {

    struct title_principals *node;
    node = find_node(ptr->roots[1], tconst);

    return node;

}
