/*
Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/

/*Include Libraries*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*Title Basics Struct*/
struct title_basics {

    char *tconst;
    char *primaryTitle;

};

/*Title Array Struct*/
struct title_array {

    struct title_basics *arr;
    long nelements;
    struct binary_tree *roots[2];

};

/*Function Prototypes*/
struct title_array* get_title(char *directory);
struct title_basics* find_primary_title(struct title_array *, char *);
struct title_basics* find_tconst(struct title_array *, char *);
void build_ptindex(struct title_array *);
void build_tindex(struct title_array *);
